#ifndef MES_FONCTIONS_H_INCLUDED
#define MES_FONCTIONS_H_INCLUDED


void ProfilIntensiteImage(cv::Mat image, char type, int numero, std::string nom_fichier_sauvegarde, std::string nom_img_origin);
void tracerTrait(cv::Mat image, char type, int numero, std::string nom_fichier_sauvegarde, std::string nom_img_origin);

#endif
