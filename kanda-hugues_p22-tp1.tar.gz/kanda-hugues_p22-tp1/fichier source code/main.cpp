
/*



                                      Institut Francophone International(IFI)

                                      TRAVAIL PRATIQUE PARTIE I ET PARTIE II  :
                       Profil d'intensite d'une image en niveau de gris ou en couleurs ET
                                       Modification de contraste d'une image
                                       PAR : HUGUES KANDA MADIMBA PROMO 22

         Description: Ce programme permet de calculer le profil d'intensite d'une image en niveaux
                                     de gris ou en couleurs(partie 1).

         Il permet aussi de modifier le niveau de contraste d'une image en utilisant trois methodes
                            differentes de modification de contraste (partie 2)

*/

#include <iostream>
#include <opencv2/opencv.hpp>
#include <stdio.h>
#include "mes_fonctions.h"
#include "fonction.h"


using namespace cv;
using namespace std;

int main( int argc, char** argv )
{
    Mat image_initiale;

    string image_initiale_string;
    string nom_sauvegarde_image;
    int numero;
    int type;
    int choix(0);
    int reponse_traitement(0);
    int position;
    char orientation;
    char nomImage[100];
    Mat image_orig, histo_orig, profil_orig, trace_orig;
    Mat image_modi, histo_modi, profil_modi, trace_modi;
    Mat courbe;






    while(1){
        cout << "\nvoulez-vous faire Quel traitement ? "<< endl;
        cout << "\t(1) PROFIL D'INTENSITE\n\t(2) MODIFICATION DE CONTRASTE\n";
        cout <<"Choix :\t";
        cin >> reponse_traitement;

        if (reponse_traitement!= 1 && reponse_traitement!=2){
            cout<<"MAUVAIS CHOIX !!! CHOISISSEZ ENTRE L'OPTION 1 ET L'OPTION 2\n";

        }

        if (reponse_traitement == 1){
            cout << "\n\n---------------------\n";
            cout<<"PARTIE I :   PROFIL D'INTENSITE\n\n";
            cout << "A) Renseigner le nom ou le chemin d'acces de votre image :\t";
            cin >> image_initiale_string;
            image_initiale = imread(image_initiale_string, 1);
            cout << image_initiale_string;

            if(!image_initiale.data){
                cout<<"\n\n\tL'IMAGE N'A PAS PU ETRE LU. MAUVAIS FORMAT OU IMAGE INEXISTANTE!!!\n\n"<<endl;

            }
            else
            {
                orientation='n';
                while(orientation!='h' && orientation!='v'){
                    cout<<"\nB) Entrez l'orientation de la ligne de profil\n";
                    cout<<"\th : horizontal\n\tv : vertical\n";
                    cout<<"Choix :\t";
                    cin>>orientation;
                    if(((orientation!='h'))&&((orientation!='v')))
                    cout<<"VEUILLEZ ENTRER \"h\" POUR HORIZONTAL ET \"v\" POUR VERTICAL\n"<<endl;
                }

                if(((orientation=='h'))||((orientation=='v'))){
                    int test=0;

                    do{
                        cout<<"\nEntrez le numero de position de la ligne ou de la colonne :\t";
                        cin>>position;

                        if(((orientation=='h')==0)&&(image_initiale.rows < position)){
                            cout<<"LE NUMERO DOIT ETRE INFERIEUR A\t"<< image_initiale.rows<<endl;
                            test =1;
                        }
                        else if(((orientation=='v')==0)&&(image_initiale.cols < position)){
                            cout <<"LE NUMERO DOIT ETRE INFERIEUR A\t"<<image_initiale.cols<<endl;
                            test = 1;
                        }
                        else{
                            test=0;
                        }
                    }while(test==1);

                    if(test==0)
                    {
                        cout<<"\nEntrez un nom pour identifier les images de sortie :\t"<<endl;
                        cin >> nom_sauvegarde_image;

                        ProfilIntensiteImage(image_initiale, orientation,position, nom_sauvegarde_image, image_initiale_string);

                        tracerTrait(image_initiale, orientation,position, nom_sauvegarde_image, image_initiale_string);
                        waitKey(0);
                        cvDestroyAllWindows();
                    }
                }
                else
                {
                    cout<<"Veuillez entrer \"h\" pour horizontal et \"v\" pour vertical\n"<<endl;
                }
            }
        }
        else if(reponse_traitement==2){
            cout << "\n\n---------------------\n";
            cout << "PARTIE II :    MODIFICATION DU CONTRASTE DE L'IMAGE\n"<<endl;
            cout << "Choisissez la fonction de modification de contraste a appliquer\n"<<endl;
            cout << "\t(1) FONCTION NON LINEAIRE AVEC CORRECTION GAMMA"<<endl;
            cout << "\t(2) FONCTION LINEAIRE A TROIS POINTS"<<endl;
            cout << "\t(3) FONCTION LINEAIRE AVEC SATURATION"<<endl;
            cout << "Choix :\t";
            cin  >> choix;

            if((choix !=1)&&(choix!=2)&&(choix!=3)){
                cout << "Le numero entre n'est pas valide\n"<<endl;
            }
            else{
                cout << "\nEntrez le nom ou le chemin d'acces de votre image :\t";
                cin  >> nomImage;
                image_orig = imread(nomImage, 1 );

                if(!image_orig.data){
                    cout << "Image non valide ou inexistante"<<endl;
                }
                else{
                    cout << "Entrez l'orientation de la ligne de profil :" << endl;
                    cout << "\t(1) pour HORIZONTAL\n\t(2) pour VERTICAL\nChoix : ";
                    cin >> type;
                    cout << "Entrez le numero de position de la ligne ou de la colonne :\t";
                    cin >> numero;

                    switch (choix)
                    {
                        case 2:
                        {

                            Point Point1, Point2, Point3;

                            cout << "Modification avec fonction linéaire à trois points"<<endl;
                            cout << " Entrez les coordonnees des trois points"<<endl;
                            cout << "Point1"<<endl;
                            cout << "x : ";
                            cin  >> Point1.x;
                            cout << "y : ";
                            cin  >> Point1.y;
                            cout << "Point2"<<endl;
                            cout << "x : ";
                            cin  >> Point2.x;
                            cout << "y : ";
                            cin  >> Point2.y;
                            cout << "Point3"<<endl;
                            cout << "x : ";
                            cin  >> Point3.x;
                            cout << "y : ";
                            cin  >> Point3.y;

                            image_modi = fonctionLineaire3Points(image_orig,Point1, Point2, Point3);
                            courbe = courbeFonctionLineaire3Points(Point1, Point2, Point3);

                            imshow( "Linéaire à 3 points", courbe );


                            if(!imwrite("fonction_lineaire.png", courbe))
                                cout<<"Erreur enregistrement de l'image"<<endl;
                            break;
                        }

                        case 1:
                        {
                        float gamma;

                            cout << "Non lineaire avec la correction gamma\n"<<endl;
                            cout << "Veuillez renseigner la valeur de gamma"<<endl;
                            cin  >> gamma;

                            image_modi = correctionGamma(image_orig,gamma);
                            courbe = courbeFonctionGamma(gamma);

                            imshow( "non lineaire avec correction gamma", courbe );

                            if(!imwrite("non_lineaire_avec_gamma.png", courbe))
                            cout<<"Erreur enregistrement de l'image"<<endl;
                            break;
                        }

                        case 3:
                        {
                            Point Point1, Point2;

                            cout << "Modification avec la fonction linéaire de saturation"<<endl;
                            cout << " Veuillez renseigner les abscisses des deux points"<<endl;
                            cout << "Min : ";
                            cin  >> Point1.x;
                            Point1.y = 0;
                            cout << "Max : ";
                            cin  >> Point2.x;
                            Point2.y = 255;

                            image_modi = fonctionLineaireSaturation(image_orig,Point1, Point2);
                            courbe = courbeFonctionLineaireSaturation(Point1, Point2);

                            imshow( "Fonction lineaire avec saturation", courbe );

                            if(!imwrite("fonction_saturation.png", courbe))
                            cout<<"Erreur enregistrement de l'image"<<endl;
                            break;
                        }
                    }

                    profil_orig = ProfilIntensiteImage2(image_orig, type, numero);
                    trace_orig = tracerTrait2(image_orig, type, numero);
                    histo_orig = histogramme(image_orig);

                    imshow("Histogramme de l'image originale", histo_orig );

                    if(!imwrite("histo_original.png", histo_orig))
                    cout<<"Erreur enregistrement de l'image"<<endl;

                    imshow( "profil d'Intensite original", profil_orig );

                    if(!imwrite("profil_Intensite_original.png", profil_orig))
                    cout<<"Erreur enregistrement de l'image"<<endl;

                    imshow( "Image originale avec trait", trace_orig );

                    if(!imwrite("image_originale_trait.png", trace_orig))
                    cout<<"Erreur enregistrement de l'image"<<endl;

                    profil_modi = ProfilIntensiteImage2(image_modi, type, numero);
                    trace_modi = tracerTrait2(image_modi, type, numero);
                    histo_modi = histogramme(image_modi);
                    imshow("Histogramme de l'image modifiee", histo_modi );
                    if(!imwrite("histo_modifie.png", histo_modi))
                    cout<<"Erreur enregistrement de l'image"<<endl;
                    imshow( "profil d'Intensite modifie", profil_modi );
                    if(!imwrite("profil_Intensite_modifie.png", profil_modi))
                    cout<<"Erreur enregistrement de l'image"<<endl;
                    imshow( "Image Modifiee avec trait", trace_modi );
                    if(!imwrite("image_modifiee_trait.png", trace_modi))
                    cout<<"Erreur enregistrement de l'image"<<endl;
                    waitKey(0);
                    cvDestroyAllWindows();
                }
            }
        }
            system("clear");
    }
}




