#include <iostream>
#include <opencv2/opencv.hpp>
#include "mes_fonctions.h"


using namespace cv; //iclusion du namespace de opencv
using namespace std;

// Fonction de détermination du profil d'intensite
void ProfilIntensiteImage(Mat image, char type, int numero, string nom_fichier_sauvegarde, std::string nom_img_origin)
{
	Point premierPoint, deuxiemePoint;
    int largeur_fenetre_courbe;
    //string nom_sauvegarde_image;
    Vec3b valeurPixelDeb;
    Vec3b valeurPixelFin;
	// Profil d'intensité dans le cas d'une ligne horizontale
	if((type=='v')==0){
		largeur_fenetre_courbe = image.cols;
	}
	else if((type=='h')==0){
		largeur_fenetre_courbe = image.rows;
	}
		// Image du profil

		Mat courbe_profil (256,largeur_fenetre_courbe,CV_8UC3,Scalar(224,224,224));

		for(int i = 0; i < largeur_fenetre_courbe-1; i++)
		{    //Recuperation des valeurs du pixel
			if((type=='v')==0){
		    valeurPixelDeb  = image.at<Vec3b>(numero, i);
		    valeurPixelFin = image.at<Vec3b>(numero,i+1);
			}
			else if((type=='h')==0){
			valeurPixelDeb  = image.at<Vec3b>(i, numero);
			valeurPixelFin = image.at<Vec3b>(i+1,numero);
			}

			for(int j = 0; j < 3; j++)
			{
				premierPoint.x = i;
				deuxiemePoint.x = i+1;
				premierPoint.y = 255 - valeurPixelDeb.val[j];
				deuxiemePoint.y = 255 - valeurPixelFin.val[j];

				// Tracé du profil pour la couleur Bleu
				if(j==0) line(courbe_profil, premierPoint, deuxiemePoint, Scalar(255, 0, 0), 1, 8);

				// Tracé du profil pour la couleur Rouge
				if(j==1) line(courbe_profil, premierPoint, deuxiemePoint, Scalar(0, 255, 0), 1, 8);

				// Tracé du profil pour la couleur Verte
				if(j==2) line(courbe_profil, premierPoint, deuxiemePoint, Scalar(0, 0, 255), 1, 8);
			}

		}

		imshow("Graphique profil d'intensite de "+nom_img_origin, courbe_profil );
		// Enregistrement dans un fichier image
		if(!imwrite("graphique_profil_intensite_"+nom_fichier_sauvegarde+".png", courbe_profil))
			cout<<"Erreur lors de l'enregistrement"<<endl;
	}





// Fonction pour tracer le trait sur l'image
void tracerTrait(Mat image, char type, int numero, string nom_fichier_sauvegarde,std::string nom_img_origin){

	Point pointDebut, pointFin;


	if ((type=='v')==0){

		pointDebut.x = 0;
		pointDebut.y = numero;
		pointFin.x = image.cols;
		pointFin.y = numero;
	}
	else if((type=='h')==0){
		pointDebut.x = numero;
		pointDebut.y = 0;
		pointFin.x = numero;
		pointFin.y = image.rows;
	}

	//Tracé de la ligne sur l'image
	//line(image, pointDebut, pointFin, Scalar(255,0,0), 4, 8);
	line(image, pointDebut, pointFin, Scalar(0,255,0), 4, 8);

	//Affichage du résultat

	imshow("Trace du profil d'intensite sur l'image : "+nom_img_origin,image);

	// Enregistrement dans un fichier image
	if(!imwrite("image_avec_profil_intensite_"+nom_fichier_sauvegarde+".png", image)) cout<<"Erreur lors de l'enregistrement de l'image"<<endl;
}
